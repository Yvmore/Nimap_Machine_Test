package com.example.demo.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entities.Categories;

public interface CategoryRepository extends JpaRepository<Categories, Long> {}