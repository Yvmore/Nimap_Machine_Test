package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entities.Products;
import com.example.demo.Entities.Categories;
import com.example.demo.Service.ProductService;
import com.example.demo.Service.CategoryService;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public ResponseEntity<Page<Products>> getAllProducts(
            @RequestParam(defaultValue = "0") int page, 
            @RequestParam(defaultValue = "10") int size) {
        return new ResponseEntity<>(productService.getAllProducts(page, size), HttpStatus.OK);
    }


    @PostMapping
    public ResponseEntity<Products> createProduct(@RequestBody Products product) {
        return new ResponseEntity<>(productService.createProduct(product), HttpStatus.CREATED);
    }

    @GetMapping("/{di}")
    public ResponseEntity<Products> getProductById(@PathVariable("di") Long di) {
        return productService.getProductById(di)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{di}")
    public ResponseEntity<Products> updateProduct(
            @PathVariable("di") Long di, 
            @RequestBody Products productDetails) {

        Products existingProduct = productService.getProductById(di)
                .orElse(null);
        
        if (existingProduct != null) {
            Categories category = categoryService.getCategoryById(productDetails.getCategoryId())
                    .orElse(null);
            
            if (category == null) {
                return ResponseEntity.badRequest().body(null);
            }
            
            existingProduct.setName(productDetails.getName());
            existingProduct.setCategory(category);
            
            Products updatedProduct = productService.updateProduct(existingProduct);
            return ResponseEntity.ok(updatedProduct);
        }
        
        return ResponseEntity.notFound().build();
    }


    @DeleteMapping("/{di}")
    public ResponseEntity<Void> deleteProduct(@PathVariable("di") Long di) {
        if (productService.deleteProduct(di)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
