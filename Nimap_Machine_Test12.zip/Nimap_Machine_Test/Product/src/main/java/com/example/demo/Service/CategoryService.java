package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.Entities.Categories;
import com.example.demo.Repository.CategoryRepository;

import java.util.Optional;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public Page<Categories> getAllCategories(int page, int size) {
        return categoryRepository.findAll(PageRequest.of(page, size));
    }

    public Categories createCategory(Categories category) {
        return categoryRepository.save(category);
    }

    public Optional<Categories> getCategoryById(Long categoryId) {
        return categoryRepository.findById(categoryId);
    }

    public Optional<Categories> updateCategory(Long id, Categories categoryDetails) {
        return categoryRepository.findById(id).map(category -> {
            category.setName(categoryDetails.getName());
            return categoryRepository.save(category);
        });
    }

    public boolean deleteCategory(Long id) {
        if (categoryRepository.existsById(id)) {
            categoryRepository.deleteById(id);
            return true;
        }
        return false;
    }
    public Categories saveCategory(Categories category) {
        if (categoryRepository.existsById(category.getId())) {
            throw new IllegalArgumentException("Category already exists.");
        }
        return categoryRepository.save(category);
    }
    
}
