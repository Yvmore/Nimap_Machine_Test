create database product_category12;
use product_category12;
create table categories (id int not null auto_increment primary key,name varchar(50) not null,description varchar(255) default null);
insert into categories (name, description) values('electronics', 'devices and gadgets'),('books', 'various genres and titles'),('clothing', 'fashion and apparel'),('toys', 'games and toys for children');
create table products (id int not null auto_increment primary key,name varchar(50) not null,category_id int not null,foreign key (category_id) references categories(id));
insert into products (name, category_id) values('smartphone', 1), ('laptop', 1),('fiction book', 2),('t-shirt', 3); 

